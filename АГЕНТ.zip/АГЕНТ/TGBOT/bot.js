import TelegramBot from 'node-telegram-bot-api';
import path from 'path';
import { fileURLToPath } from 'url';
import { token, ADMIN_ID } from './config.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

if (!token) {
    console.error('Ошибка: Токен не найден');
    process.exit(1);
}

const bot = new TelegramBot(token, { polling: true });

const webAppUrl = 'https://agent-6n7f.onrender.com';
const imagePath = path.join(__dirname, 'photo_2025-12-31_02-07-09.jpg');

bot.on('message', async (msg) => {
    const chatId = msg.chat.id;
    const text = msg.text;
    const user = msg.from;

    if (text === '/start') {
        // Если пишет сам админ - сразу пускаем
        // Приведение типов к строке/числу для надежного сравнения
        if (String(chatId) === String(ADMIN_ID)) {
            await sendWelcomeMessage(chatId);
            return;
        }

        // Уведомляем пользователя
        await bot.sendMessage(chatId, '✋ **Ваш запрос на рассмотрении.**\n\nПожалуйста, подождите подтверждения от администратора.', { parse_mode: 'Markdown' });

        // Отправляем запрос админу
        const username = user.username ? `@${user.username}` : 'Без юзернейма';
        const name = `${user.first_name || ''} ${user.last_name || ''}`.trim();

        const adminMsg = `👤 **Новый пользователь запросил доступ!**\n\n` +
            `🆔 ID: \`${user.id}\`\n` +
            `👤 Имя: ${name}\n` +
            `🔗 Профиль: ${username}`;

        await bot.sendMessage(ADMIN_ID, adminMsg, {
            parse_mode: 'Markdown',
            reply_markup: {
                inline_keyboard: [
                    [
                        { text: '✅ Принять', callback_data: `accept_${chatId}` },
                        { text: '❌ Отклонить', callback_data: `reject_${chatId}` }
                    ]
                ]
            }
        });
    }
});

bot.on('callback_query', async (query) => {
    const { data, message } = query;
    const adminChatId = message.chat.id;
    const messageId = message.message_id;

    // Проверяем, что нажал админ (на всякий случай)
    if (String(adminChatId) !== String(ADMIN_ID)) return;

    if (data.startsWith('accept_')) {
        const userId = data.split('_')[1];

        // 1. Отправляем пользователю приветствие
        await sendWelcomeMessage(userId);

        // 2. Обновляем сообщение у админа
        await bot.editMessageText(`${message.text}\n\n✅ **Доступ предоставлен.**`, {
            chat_id: adminChatId,
            message_id: messageId,
            parse_mode: 'Markdown'
        });

    } else if (data.startsWith('reject_')) {
        const userId = data.split('_')[1];

        // 1. Отправляем пользователю отказ
        await bot.sendMessage(userId, '⛔ **В доступе отказано.**\n\nСвяжитесь с администратором для уточнения деталей.', { parse_mode: 'Markdown' });

        // 2. Обновляем сообщение у админа
        await bot.editMessageText(`${message.text}\n\n❌ **Доступ отклонен.**`, {
            chat_id: adminChatId,
            message_id: messageId,
            parse_mode: 'Markdown'
        });
    }

    // Убираем часики загрузки с кнопки
    await bot.answerCallbackQuery(query.id);
});

async function sendWelcomeMessage(chatId) {
    try {
        await bot.sendPhoto(chatId, imagePath, {
            caption: '🎓 **Добро пожаловать в Академию Здравого Трейдера!**\n\n' +
                'Твой личный AI-агент готов к работе.\n' +
                'Здесь нет места эмоциям - только холодный расчет и профит. 🧠\n\n' +
                'Помни правило: **No Money - No Honey**. 💸\n\n' +
                'Жми кнопку ниже для запуска 👇',
            parse_mode: 'Markdown',
            reply_markup: {
                inline_keyboard: [
                    [{ text: '🚀 Открыть', web_app: { url: webAppUrl } }]
                ]
            }
        });
    } catch (error) {
        console.error('Ошибка при отправке фото:', error);
        // Fallback
        await bot.sendMessage(chatId, 'Привет! 👋\n\nНажми на кнопку ниже, чтобы запустить приложение.', {
            reply_markup: {
                inline_keyboard: [
                    [{ text: '🚀 Открыть', web_app: { url: webAppUrl } }]
                ]
            }
        });
    }
}

console.log('Бот запущен с системой администрирования...');
