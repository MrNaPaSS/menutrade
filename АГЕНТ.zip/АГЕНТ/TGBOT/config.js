export const token = '8392573674:AAHJLOXX-38RRNGeEmAiE_ZyJBmTQsldGUE';
export const ADMIN_ID = 511442168;
